// node --test src/eval.test.js    (or: npm test)
//
// The scoreboard has to be trustworthy before anything it says is worth
// acting on, so the metric itself gets tested: a ranking that knows nothing
// must score like chance, and a ranking that knows everything must not.

import assert from 'node:assert/strict';
import { test } from 'node:test';

import { SCHEMA_VERSION, Store, HORIZONS } from './store.js';
import { evaluate, leadTimeSeconds, loadRows } from './eval.js';

const BASE = Date.parse('2026-11-19T20:00:00Z');
const at = (seconds) => new Date(BASE + seconds * 1000).toISOString();

test('lead time is measured against a different clipper, not the same one', () => {
  // One person firing off four clips of their own moment is one person.
  // Counting that as competition would flatter every number downstream.
  const sameGuy = [
    { creator_name: 'alice', created_at: at(0) },
    { creator_name: 'alice', created_at: at(20) },
    { creator_name: 'alice', created_at: at(40) },
  ];
  assert.equal(leadTimeSeconds(sameGuy), null);

  const rival = [...sameGuy, { creator_name: 'bob', created_at: at(90) }];
  assert.equal(leadTimeSeconds(rival), 90);
});

test('lead time is null when nobody else ever turned up', () => {
  assert.equal(leadTimeSeconds([]), null);
  assert.equal(leadTimeSeconds([{ creator_name: 'alice', created_at: at(0) }]), null);
});

const rows = (pairs) =>
  pairs.map(([momentId, opportunity, views], i) => ({
    momentId,
    opportunity,
    views,
    source: i % 2 ? 'chat' : 'clips',
    leadTimeSeconds: 60,
  }));

test('a ranking that knows nothing scores like chance', () => {
  // Opportunity is uncorrelated with views here, so lift must sit near 1.
  const data = rows(
    Array.from({ length: 100 }, (_, i) => [`m${i}`, i % 10, ((i * 37) % 100) * 10]),
  );
  const result = evaluate(data, { topN: 20 });
  assert.ok(result.enough);
  assert.ok(result.lift < 2, `a blind ranking should not show lift, got ${result.lift}`);
});

test('a ranking that is right scores far above chance', () => {
  const data = rows(Array.from({ length: 100 }, (_, i) => [`m${i}`, i, i * 10]));
  const result = evaluate(data, { topN: 20 });
  assert.equal(result.precision, 0.5); // the 10 winners all sit inside the top 20
  assert.ok(result.lift > 4, `expected strong lift, got ${result.lift}`);
});

test('too little history says so instead of printing a confident zero', () => {
  assert.equal(evaluate([]).enough, false);
  assert.equal(evaluate(rows([['m1', 1, 1]])).enough, false);
});

test('the store round-trips a poll and an outcome', () => {
  const store = new Store(':memory:');
  const moment = {
    id: 'm1',
    broadcasterId: '1',
    broadcaster: 'streamer',
    vodId: 'v1',
    offsetSeconds: 1000,
    source: 'clips',
    title: 'a moment',
    saturation: 2,
    uniqueClippers: 2,
    clipViews: 10,
    chatZ: 3,
    opportunity: 4.2,
    firstClipAt: at(0),
    clipIds: ['c1', 'c2'],
  };
  const clipsById = new Map([
    ['c1', { id: 'c1', creator_name: 'alice', created_at: at(0), view_count: 4 }],
    ['c2', { id: 'c2', creator_name: 'bob', created_at: at(120), view_count: 6 }],
  ]);

  store.recordPoll({ moments: [moment], clipsById, at: new Date(BASE) });
  // A second poll of the same moment must not duplicate it.
  store.recordPoll({ moments: [moment], clipsById, at: new Date(BASE + 30_000) });

  const counts = store.counts();
  assert.equal(counts.moments, 1);
  assert.equal(counts.clips, 2);
  assert.equal(counts.observations, 2);

  store.recordOutcome({
    momentId: 'm1',
    horizon: HORIZONS[0],
    clips: [
      { id: 'c1', creator_name: 'alice', created_at: at(0), view_count: 400 },
      { id: 'c2', creator_name: 'bob', created_at: at(120), view_count: 600 },
    ],
    at: new Date(BASE + 900_000),
  });

  const [row] = loadRows(store, '15m');
  assert.equal(row.momentId, 'm1');
  assert.equal(row.views, 1000);
  // Earliest observation wins: what the feed said when it was still actionable.
  assert.equal(row.opportunity, 4.2);
  assert.equal(row.leadTimeSeconds, 120);
  store.close();
});

test('a moment is only due for a horizon it has not been checked at', () => {
  const store = new Store(':memory:');
  store.recordPoll({
    moments: [{ id: 'm1', broadcaster: 'x', saturation: 1, clipIds: [] }],
    at: new Date(BASE),
  });

  const horizon = HORIZONS[0]; // 15m
  assert.deepEqual(store.dueForOutcome(horizon, { now: BASE + 60_000 }), []);
  assert.deepEqual(store.dueForOutcome(horizon, { now: BASE + 20 * 60_000 }), ['m1']);

  store.recordOutcome({ momentId: 'm1', horizon, clips: [] });
  assert.deepEqual(store.dueForOutcome(horizon, { now: BASE + 20 * 60_000 }), []);
  // Later horizons are still owed.
  assert.deepEqual(store.dueForOutcome(HORIZONS[1], { now: BASE + 2 * 3600_000 }), ['m1']);
  store.close();
});

test('a moment first seen in chat and later confirmed is recorded as both', () => {
  const store = new Store(':memory:');
  store.recordPoll({
    moments: [{ id: 'm1', broadcaster: 'x', source: 'chat', saturation: 0, clipIds: [] }],
    at: new Date(BASE),
  });
  store.recordPoll({
    moments: [{ id: 'm1', broadcaster: 'x', source: 'clips', saturation: 2, clipIds: [] }],
    at: new Date(BASE + 60_000),
  });

  const [row] = store.all('select source, detected_at from moments where id = ?', 'm1');
  assert.equal(row.source, 'both');
  // detected_at is when WE first saw it and must never be overwritten — it is
  // the number the whole product is judged on.
  assert.equal(row.detected_at, new Date(BASE).toISOString());
  store.close();
});

test('the schema records its version so a later one can migrate it', () => {
  const store = new Store(':memory:');
  assert.equal(store.version, SCHEMA_VERSION);
  assert.equal(store.all('pragma user_version')[0].user_version, SCHEMA_VERSION);
  store.close();
});

test('pruning drops the bulk but never the row eval depends on', () => {
  const store = new Store(':memory:');
  const moment = { id: 'm1', broadcaster: 'x', saturation: 1, clipIds: [], opportunity: 7 };

  // One moment, polled every 30s for a simulated month.
  for (let i = 0; i < 40; i += 1) {
    store.recordPoll({ moments: [{ ...moment }], at: new Date(BASE + i * 86_400_000) });
  }
  assert.equal(store.counts().observations, 40);

  const pruned = store.pruneOlderThan(14, { now: BASE + 40 * 86_400_000 });
  assert.ok(pruned.observations > 0, 'expected old observations to go');

  // The earliest observation is what the feed claimed while the moment was
  // still actionable, so eval reads it and prune must never take it.
  const remaining = store.all('select observed_at from observations order by observed_at asc');
  assert.equal(remaining[0].observed_at, new Date(BASE).toISOString());
  assert.equal(store.counts().moments, 1);
  store.close();
});

test('the longitudinal tables are never pruned', () => {
  // The clipper index is built from these and cannot be re-collected, so
  // pruning them would throw away the one asset nothing can rebuild.
  const store = new Store(':memory:');
  store.recordPoll({
    moments: [{ id: 'm1', broadcaster: 'x', saturation: 1, clipIds: ['c1'] }],
    clipsById: new Map([['c1', { id: 'c1', creator_name: 'alice', created_at: at(0), view_count: 1 }]]),
    at: new Date(BASE),
  });
  store.recordOutcome({ momentId: 'm1', horizon: HORIZONS[0], clips: [], at: new Date(BASE) });

  store.pruneOlderThan(1, { now: BASE + 400 * 86_400_000 });

  const counts = store.counts();
  assert.equal(counts.moments, 1);
  assert.equal(counts.clips, 1);
  assert.equal(counts.outcomes, 1);
  store.close();
});

const ranked = (n, viewsFor) =>
  Array.from({ length: n }, (_, i) => ({
    momentId: `m${i}`,
    opportunity: i,
    views: viewsFor(i, n),
    source: 'clips',
    leadTimeSeconds: 60,
  }));

test('a perfect ranking below the floor is refused, not scored as chance', () => {
  // opportunity exactly proportional to views: there is no better ranking than
  // this one, so anything the metric says against it is the metric's fault.
  const perfect = (n) => ranked(n, (i) => i * 10);

  // At or below topN every moment already sits inside the top N, so precision
  // is the base rate and lift is exactly 1. The old floor of 2 published that
  // as "does not beat chance" for a flawless ranking.
  const small = evaluate(perfect(20), { topN: 20 });
  assert.equal(small.enough, false);
  assert.equal(small.needed, 100);

  // Twice topN is refused too, and for the opposite reason: there the top N is
  // half the field, so a BLIND ranking catches every winner by coverage and
  // also scores the ceiling. A number here cannot distinguish the two.
  assert.equal(evaluate(perfect(40), { topN: 20 }).enough, false);

  const scored = evaluate(perfect(100), { topN: 20 });
  assert.equal(scored.enough, true);
  assert.equal(scored.lift, 5);
});

test('a blind ranking is not blessed by a small population', () => {
  // The same rows that earn a blind ranking full marks at n=40 must earn it
  // nothing once the population is big enough to tell.
  const blind = (n) => ranked(n, (i) => ((i * 37) % 100) * 10);
  assert.equal(evaluate(blind(40), { topN: 20 }).enough, false);
  assert.equal(evaluate(blind(100), { topN: 20 }).lift, 1);
});

test('a measured lift is reported against the best the sample could show', () => {
  // The winners set is a decile of the population, so the ceiling moves with n:
  // 5x at 100 moments, 10x at 200. A 2x that was all 2x could ever be is not a
  // weak signal, and the report must not let those two read the same.
  const result = evaluate(ranked(100, (i) => i * 10), { topN: 20 });
  assert.equal(result.maxLift, 5);
  assert.equal(result.lift, result.maxLift);

  const bigger = evaluate(ranked(200, (i) => i * 10), { topN: 20 });
  assert.equal(bigger.maxLift, 10);
});
